// variables de datos

// variables globales

// Funciones para recoger los datos

// Funciones para escribir resultados

// Funciones de tratamiento de las listas

// Funciones activadas por eventos

// Activacion y desactivación de eventos

// Funciones al cargar la página
