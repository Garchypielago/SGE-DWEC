// Ciudades a añadir como opciones al input select
const cities = ["Granada", "Valencia", "Madrid", "Toledo"];

/*

Estos métodos describen cómo asignar datos a un objeto DOM creado dinámicamente
y cómo usarlos al lanzar el evento enlazado al objeto

function usarDatosObjetoDOM() {
// this es el objeto que invoca el evento, obj en la función crearObjetoDOM
  let informacion = this.info;
  console.log("usarDatosObjetoDOM:" + informacion);
}

function crearObjetoDOM() {
  const obj = document.createElement(tag);
  let informacion = {a:10, b:"data"}
  obj.info = informacion;
  obj.addEventListener("click", usarDatosObjetoDOM);
}

Estilos a añadir a cada círculo con el campo a asignar del objeto

left : obj.ejex  en px ; ej: 20px
top : obj.ejey en px
width : obj.box en px
height : obj.box en px
boxShadow : 0 0 0 obj.margin en px obj.colormargin; ej: 0 0 0 30px #f799f0
backgroundColor : obj.colorbox;

Además hay que añadir la clase circle
*/
