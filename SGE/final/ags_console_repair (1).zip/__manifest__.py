{
    "name": "AGS Console Repair Workshop",
    "version": "17.0.1.0.0",
    "author": "Alumno AGS",
    "license": "LGPL-3",
    "category": "Services",
    "depends": ["base"],
    "application": True,
    "data": [
        "security/ags_console_repair_security.xml",
        "security/ir.model.access.csv",
        "views/menu.xml",
        "views/customer_views.xml",
        "views/console_views.xml",
        "views/repair_order_views.xml",
        "data/demo_data.xml"
    ]
}
