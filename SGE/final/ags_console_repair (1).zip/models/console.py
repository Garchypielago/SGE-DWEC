from odoo import models, fields

class AgsConsole(models.Model):
    _name = "ags.console"
    _description = "Consola"

    name = fields.Char(string="Alias", required=True)
    serial_number = fields.Char(string="Número de serie", required=True, copy=False, index=True)
    console_type = fields.Selection([
        ("ps", "PlayStation"),
        ("xbox", "Xbox"),
        ("switch", "Nintendo Switch"),
        ("other", "Otra")
    ], required=True, default="other", string="Tipo")
    purchase_date = fields.Date(string="Fecha de compra")
    in_warranty = fields.Boolean(string="En garantía", default=True)
    customer_id = fields.Many2one("ags.customer", string="Propietario", required=True, ondelete="cascade")
    repair_ids = fields.One2many("ags.repair.order", "console_id", string="Reparaciones")
