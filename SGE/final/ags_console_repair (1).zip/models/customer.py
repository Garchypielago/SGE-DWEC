from odoo import models, fields

class AgsCustomer(models.Model):
    _name = "ags.customer"
    _description = "Cliente"

    name = fields.Char(string="Nombre", required=True)
    email = fields.Char(string="Email")
    phone = fields.Char(string="Teléfono")
    address = fields.Char(string="Dirección")
    join_date = fields.Date(string="Fecha de alta", default=fields.Date.today)
    console_ids = fields.One2many("ags.console", "customer_id", string="Consolas")
