from odoo import models, fields, api

class AgsRepairOrder(models.Model):
    _name = "ags.repair.order"
    _description = "Orden de reparación"
    _order = "create_date desc"

    name = fields.Char(string="Referencia", copy=False, readonly=True, default="New")
    console_id = fields.Many2one("ags.console", string="Consola", required=True, ondelete="cascade")
    customer_id = fields.Many2one("ags.customer", related="console_id.customer_id", store=True, readonly=True)
    start_date = fields.Date(string="Inicio", default=fields.Date.today)
    end_date = fields.Date(string="Fin")
    issue_description = fields.Text(string="Descripción del problema")
    cost = fields.Float(string="Coste")
    state = fields.Selection([
        ("draft", "Borrador"),
        ("in_progress", "En progreso"),
        ("done", "Finalizado"),
        ("cancelled", "Cancelado")
    ], string="Estado", default="draft", tracking=True)

    @api.model
    def create(self, vals):
        if vals.get("name", "New") == "New":
            vals["name"] = self.env["ir.sequence"].next_by_code("ags.repair.order") or "New"
        return super().create(vals)
